// Header file TREE.H for tree-walking code.

typedef struct _NODE {
	struct _NODE *pLeftChild;
	struct _NODE *pRightChild;
} NODE;
